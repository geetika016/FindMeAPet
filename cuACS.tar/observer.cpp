#include "observer.h"

Observer::Observer(QWidget *parent) : QWidget(parent)
{
}

Observer::~Observer()
{
}
