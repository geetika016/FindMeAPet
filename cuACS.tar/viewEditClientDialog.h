#ifndef CLIENTPROFILEVIEW_H
#define CLIENTPROFILEVIEW_H

#include <QDialog>
#include <QtDebug>
#include <QSlider>
#include <QMessageBox>
#include "clientDatabaseControl.h"

class ViewEditClientDialog;
class ClientDatabaseControl;

namespace Ui {
class ViewEditClientDialog;
}

class ViewEditClientDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ViewEditClientDialog(QString name, QWidget *parent = 0);
    ~ViewEditClientDialog();
//signals:
    //void myProfile();

private slots:
    void on_saveButton_clicked();

private:
    Ui::ViewEditClientDialog *ui;
    QString username;
    ClientDatabaseControl *dbControl;
};

#endif // CLIENTPROFILEVIEW_H
