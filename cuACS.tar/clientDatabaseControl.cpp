#include "clientDatabaseControl.h"

ClientDatabaseControl::ClientDatabaseControl(QString name, QObject *parent) :
    QObject(parent),
    username(name)
{
    dbControl = new DatabaseControl;
}

bool ClientDatabaseControl::dbRequest(void *input, void *output, int id, QString *errMsg)
{
    QString name = username;
    DBSettings settings;
    switch (id) {
    case EDIT_CLIENT:
        settings.table = "clients";
        dbControl->dbRequest(&name, output, &settings, READ, errMsg);
        break;

    default:
        break;
    }
    return true;
}

bool ClientDatabaseControl::editClientRequest(ClientInfo *output, QString *errMsg)
{
    //read from the db
    struct DBSettings settings;
    settings.table = QString("clients");
    dbControl->dbRequest((void *)&username, (void *)output, &settings, READ, errMsg);
    //the passing process of username: Proxy->ClientMainWindow->ViewEditClientDialog->ClientDBControl
    return true;
}

bool ClientDatabaseControl::viewAnimalRequest(DataModel *output, QString *errMsg)
{
    struct DBSettings settings;
    settings.table = QString("animals");
    settings.editStrategy = QSqlTableModel::OnManualSubmit;
    ColHeaderOperation colHeaderOperation;
    colHeaderOperation.name = QString("replace");
    colHeaderOperation.arg1 = QString("_");
    colHeaderOperation.arg2 = QString(" ");
    settings.colHeaderOperation = &colHeaderOperation;
    CellsOperation cellsOperation;
    cellsOperation.name = QString("overwrite");
    cellsOperation.dataType = QMetaType::QString;
    cellsOperation.arg1 = QString("");
    cellsOperation.arg2 = QString("N/A");
    settings.colHeaderOperation = &colHeaderOperation;
    settings.cellsOperation = &cellsOperation;
    return dbControl->dbRequest(NULL, output, &settings, MODEL, errMsg);
}
