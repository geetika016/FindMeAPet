#include "viewEditClientDialog.h"
#include "ui_viewEditClientDialog.h"

ViewEditClientDialog::ViewEditClientDialog(QString name, QWidget *parent) :
    username(name),
    QDialog(parent),
    ui(new Ui::ViewEditClientDialog)
{
    ui->setupUi(this);
    dbControl = new ClientDatabaseControl(username);
    ui->animal_Characteristics->setCurrentIndex(0);
    ui->dog_characteristics_tab->setCurrentIndex(0);
    ui->cat_characteristics_tab->setCurrentIndex(0);
    connect(ui->client_animal_type,SIGNAL(currentIndexChanged(int)),ui->animal_Characteristics,SLOT(setCurrentIndex(int)));
}

ViewEditClientDialog::~ViewEditClientDialog()
{
    delete ui;
    delete dbControl;
}

/*
 * call function like this in save button handler:
 * ClientInfo output;// output structure
 * QString errMsg;
 * dbControl->dbRequest(NULL, output, EDIT_CLIENT, errMsg);
 * //won't pass any input, the clientdbcontrol should know how to do since we specify "EDIT_CLIENT" here.
*/


void ViewEditClientDialog::on_saveButton_clicked()
{
    QHash<QString, QString> output;
    QString errMsg;
    if (!dbControl->dbRequest(NULL, &output, EDIT_CLIENT, &errMsg))
        QMessageBox::critical(NULL, "Database Error", errMsg);

}
