#ifndef CLIENTLISTVIEW_H
#define CLIENTLISTVIEW_H

#include <QWidget>
#include <QtSql>
#include <QMessageBox>
#include "ui_viewClientWidget.h"
#include "dataModel.h"
#include "staffDatabaseControl.h"
#include "observer.h"

#define CLIENT_SUMMARY_ATTRIBUTES_NUM 3

/*
  Class: ViewClientWidget
  Purpose: displays a table for feature ViewAnimals, also takes in charge the control flow of the feature

  Member function: constructor
  Purpose: creates a data model for in program storage, also provides format info for QTableView object

  Member function: buildDataModel
  Purpose: intializes and polulates the model

  Member function: configure()
  Purpose: set up the QTableView object

*/

class ViewClientWidget : public Observer
{
    Q_OBJECT

private:
    Ui::ViewClientWidget ui;
    DataModel *model;
    StaffDatabaseControl *dbControl;
    static QString summaryAttributes[CLIENT_SUMMARY_ATTRIBUTES_NUM];

public:
    explicit ViewClientWidget(QWidget *parent = nullptr);
    ~ViewClientWidget();
    void configure(QTableView *tableView, QString *attributes, int attributesShown);    
    virtual void update(Subject * subject);
};

#endif // CLIENTLISTVIEW_H
