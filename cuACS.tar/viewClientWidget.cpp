#include "viewClientWidget.h"

QString ViewClientWidget::summaryAttributes[CLIENT_SUMMARY_ATTRIBUTES_NUM] = {
    "name", "phone_number", "email"
};

ViewClientWidget::ViewClientWidget(QWidget *parent) : Observer(parent)
{
    ui.setupUi(this);
    model = new DataModel;
    dbControl = new StaffDatabaseControl;
    if (!dbControl->dbRequest(NULL, model, VIEW_CLIENT))
    {
        QMessageBox::critical(NULL, QObject::tr("Error!"),  QObject::tr("Unable to build dataModel"));
        return;
    }
    //set up the view object
    configure(ui.tableView_summary, summaryAttributes, CLIENT_SUMMARY_ATTRIBUTES_NUM);
}

ViewClientWidget::~ViewClientWidget()
{
    delete(model);
    delete(dbControl);
}

void ViewClientWidget::configure(QTableView *tableView, QString *attributes, int attributesShown)
{
    //set up the View object
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    tableView->setWindowTitle(QObject::tr("Clients Table"));
    tableView->setModel(model);
    tableView->setCurrentIndex(model->index(0, 0));
    for(int i=0; i<model->columnCount(); i++)
        tableView->hideColumn(i);
    for(int i=0; i<attributesShown; i++)
        tableView->setColumnHidden(model->fieldIndex(attributes[i]), false);
    tableView->horizontalHeader()->setStretchLastSection(true);
    tableView->resizeColumnsToContents();
    tableView->show();
}

void ViewClientWidget::update(Subject * subject)
{
    if (!dbControl->dbRequest(NULL, model, VIEW_CLIENT))
    {
        QMessageBox::critical(NULL, QObject::tr("Error!"),  QObject::tr("Unable to build dataModel"));
        return;
    }
    configure(ui.tableView_summary, summaryAttributes, CLIENT_SUMMARY_ATTRIBUTES_NUM);
}
