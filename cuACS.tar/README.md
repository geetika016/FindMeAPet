# Installation Instructions
To install and run cuACS:
- Execute run.sh with the command ./run.sh
  - If this does not work, execute the command "chmod +x run.sh" to give execute permissions to the file
- When run.sh is executed, it builds and runs cuACS
  - After executing run.sh the first time, you may execute the command ./cuACS in the future to run the program.
- To login to the system, enter "matilda23" into the **username** field and "matilda23" into the **password** field and click **login**.

# About
COMP 3004 - Object-Oriented Software Engineering

Team Name: import team_name

Authors:
- Tyler Despatie
- Minna Amin
- Zhaorong Wang
- Geetika Sharma

# Github Cheat Sheet
https://services.github.com/on-demand/downloads/github-git-cheat-sheet/
