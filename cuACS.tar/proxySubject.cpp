#include "proxySubject.h"

ProxySubject::ProxySubject(QWidget *parent) : QMainWindow(parent)
{
}

ProxySubject::~ProxySubject()
{
}
